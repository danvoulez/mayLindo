#!/bin/sh
TRACE_ID="simulacao-$(date +%s)"
mkdir -p spans
FLOW=$1
OUT="spans/$(basename "$FLOW" .logline).jsonl"
cat "$FLOW" | grep "^call(" | while read -r line; do
  CODE=$(echo "$line" | sed -E 's/call\((.*)\)/\1/')
  SPAN_ID=$(date +%s%N)
  START=$(date -Iseconds)
  echo "{"span_id":"$SPAN_ID","trace_id":"$TRACE_ID","type":"call","start":"$START","latency_ms":1,"status":"simulated","code":"$CODE"}" >> "$OUT"
done