#!/bin/sh
echo "reset_seguro_ok"