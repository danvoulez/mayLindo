#!/bin/sh
echo "log_local_ok"