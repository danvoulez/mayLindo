#!/bin/sh
echo "normalizar_temperatura_ok"