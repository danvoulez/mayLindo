#!/bin/sh
echo "sensor_backup_ok"