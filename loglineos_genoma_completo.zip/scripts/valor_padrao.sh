#!/bin/sh
echo "valor_padrao_ok"