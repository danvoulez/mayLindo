#!/bin/sh
echo "sensor_temperatura_ok"