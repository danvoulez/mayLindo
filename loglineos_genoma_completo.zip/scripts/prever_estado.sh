#!/bin/sh
echo "prever_estado_ok"